//
//  gender.h
//  LocalSTI
//
//  Created by David CHAMPREDON on 2014-08-21.
//  Copyright (c) 2014 David CHAMPREDON. All rights reserved.
//

#ifndef LocalSTI_gender_h
#define LocalSTI_gender_h

enum Gender {female,male};

#endif
