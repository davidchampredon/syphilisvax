//
//  main_SFW.h
//  
//
//  Created by David CHAMPREDON on 11/18/2013.
//
//

#ifndef ____main_SFW__
#define ____main_SFW__

#include <iostream>

#endif /* defined(____main_SFW__) */
